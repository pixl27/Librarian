-- 1663850's Lua and Manifest Created by Hubcap Manifest
-- REPLACED
-- Created: April 17, 2026 at 13:40:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1663850) -- REPLACED
-- MAIN APP DEPOTS
addappid(1663851, 1, "6c5ad07d24ba971709a2773ed2263ddc46bf21f9a2608989ef9438668db72760") -- Depot 1663851
setManifestid(1663851, "7705641233008622250", 5944325537)