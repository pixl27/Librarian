-- 113200's Lua and Manifest Created by Morrenus
-- The Binding of Isaac
-- Created: September 30, 2025 at 22:43:51 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 7
-- Total DLCs: 4

-- MAIN APPLICATION
addappid(113200) -- The Binding of Isaac
-- MAIN APP DEPOTS
addappid(113201, 1, "dc46feac7ce6fc9f0620f632205abb4ed111519738ebcca5cb8593b96fe79350") -- BOI Content
setManifestid(113201, "7053554676601365183", 48536540)
addappid(113202, 1, "9e69039d873162e477325961ff4a656c072ecec3ceef660e15b1c385858a374e") -- BOI Mac
setManifestid(113202, "3180483545280594364", 54985432)
-- DLCS WITH DEDICATED DEPOTS
-- Binding of Isaac Soundtrack (AppID: 113203)
addappid(113203)
addappid(113203, 1, "b5cba50948d0305ebde3371d94859ca28fb851407c66be924e02888de9d10802") -- Binding of Isaac Soundtrack - Binding of Isaac Soundtrack
setManifestid(113203, "7017059398181616414", 276225111)
-- Binding of Isaac Wrath of the Lamb (AppID: 113204)
addappid(113204)
addappid(113204, 1, "05562ce646f2fc39742720cf096bf8fee36ab13993609dbe48f87451ec9f6bd6") -- Binding of Isaac Wrath of the Lamb - Wrath of the Lamb
setManifestid(113204, "6614082919839273692", 38854527)
-- The Binding Of Isaac - Wrath of the Lamb (AppID: 113205)
addappid(113205)
addappid(113205, 1, "847e6dd2cb0127abffeb458938c293384e72d1031a0ead9a4ff03bbb104bdf81") -- The Binding Of Isaac - Wrath of the Lamb - Wrath of the Lamb Mac
setManifestid(113205, "190163795382615836", 51489158)
-- The Binding of Isaac Wrath of the Lamb Eternal Edition (AppID: 368010)
addappid(368010)
addappid(368010, 1, "ef8ea30154f995c4e4226df06f5cc39705ef0fc2d800f948613d1b3dd6b6437e") -- The Binding of Isaac Wrath of the Lamb Eternal Edition - The Binding of Isaac: Wrath of the Lamb Eternal Edition (368010) Depot
setManifestid(368010, "6622130648560741481", 49411581)
addappid(113206, 1, "2f6ec6d6771460d872d815dd7190331aa9eea92b510d52ab72e223bd8602efde") -- The Binding of Isaac Wrath of the Lamb Eternal Edition - The Binding of Isaac Depot Wrath of the Lamb Eternal OSX
setManifestid(113206, "8639075337300603337", 61445268)